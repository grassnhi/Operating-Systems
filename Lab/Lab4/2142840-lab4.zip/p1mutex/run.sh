make clean
make shrdmem
./shrdmem
