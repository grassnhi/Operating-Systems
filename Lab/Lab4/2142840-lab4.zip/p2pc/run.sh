make clean
make pc
./pc
