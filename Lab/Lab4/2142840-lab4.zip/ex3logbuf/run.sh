make clean
make logbuf
./seqlock